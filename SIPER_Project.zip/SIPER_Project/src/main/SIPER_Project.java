package main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author Abhirama Aji Mahardhika
 */
public class SIPER_Project extends Application {
    
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/view/StartupScene.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.getIcons().add(new Image("png/SIPER ICON.png"));
        stage.setTitle("SIPER");
        stage.setScene(scene);
        stage.sizeToScene();
        stage.show();
    }
    
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
