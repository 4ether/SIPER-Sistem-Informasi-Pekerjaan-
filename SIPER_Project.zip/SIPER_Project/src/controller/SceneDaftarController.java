package controller;

import model.SwitchPage;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import static javafx.collections.FXCollections.observableArrayList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import model.AdminData;
import model.DataUser;
import model.SaveData;

public class SceneDaftarController implements Initializable {
    
    AdminData ad = new AdminData();
    
    String ademail = ad.getEmail();
    String adepass = ad.getPassword();
    
    ObservableList data = observableArrayList();
        
    
    @FXML
    private TextField tfNama;
    @FXML
    private TextField tfEmail;
    @FXML
    private TextField tfPass;
    @FXML
    private TextField tfNoTelp; 
    @FXML
    private TableView tvUtama;
    @FXML
    private TableColumn tvNama;
    @FXML
    private TableColumn tvEmail;
    @FXML
    private TableColumn tvPassword;
    @FXML
    private TableColumn tvNomorTelp;
    @FXML
    private Button btnDaftar;
    @FXML
    private Text txMasuk;
    @FXML
    private Button btnBeranda;
    @FXML
    private RadioButton rbLaki;
    @FXML
    private RadioButton rbPerempuan;
    @FXML
    private Label lbGender;
    @FXML
    private TableColumn tvGender;

    
    
    public void addDatabase(String nama, String email, String password, String notelp, String gender){
        data.add(new DataUser(nama, email, password, notelp, gender));
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {    
        try {
            SaveData sd = new SaveData();
            data = sd.ambilDaftarSimpanUser("DataUser");
            tvNama.setCellValueFactory(new PropertyValueFactory<DataUser, String>("nama"));
            tvEmail.setCellValueFactory(new PropertyValueFactory<DataUser, String>("email"));
            tvPassword.setCellValueFactory(new PropertyValueFactory<DataUser, String>("password"));
            tvNomorTelp.setCellValueFactory(new PropertyValueFactory<DataUser, String>("notelp"));
            tvGender.setCellValueFactory(new PropertyValueFactory<DataUser, String>("gender"));
            tvUtama.setItems(data);
        } catch(Exception e){
            System.out.println("Database akun belum ada!");
        }
         
    }    
    

    @FXML
    private void btnUserDaftar (ActionEvent event) {
        
        ArrayList<String> emList = new ArrayList<String>();
        ArrayList<String> psList = new ArrayList<String>();
        ArrayList<String> ntList = new ArrayList<String>();
        
        String nama = tfNama.getText();
        String email = tfEmail.getText();
        String pass = tfPass.getText();
        String notelp = tfNoTelp.getText(); 
        
        String gender = lbGender.getText();

        for (int i = 0; i < tvUtama.getItems().size(); i++) {
            emList.add(tvEmail.getCellData(i).toString());
            psList.add(tvPassword.getCellData(i).toString());
            ntList.add(tvNomorTelp.getCellData(i).toString());
        }   
        if(nama.isEmpty() || email.isEmpty() || pass.isEmpty() || notelp.isEmpty() || lbGender.getText().equals("null")) {
            try{
                Alert art = new Alert(Alert.AlertType.ERROR);
                art.setHeaderText(null);
                art.setContentText("Mohon masukan semua data yang dibutuhkan!");
                art.show();
            } catch (Exception e){
                System.out.println(e);
            }
        } else if (emList.contains(email) || emList.contains(email) && psList.contains(pass) || ntList.contains(notelp)){
            Alert art = new Alert(Alert.AlertType.ERROR);
                art.setHeaderText(null);
                art.setContentText("Akun atau No Telp Sudah Ada!");
                art.show();
        } else if (email.equals(ademail)){
            Alert art = new Alert(Alert.AlertType.ERROR);
                art.setHeaderText(null);
                art.setContentText("Akun atau No Telp Sudah Ada!");
                art.show();
        } else {
            addDatabase(nama, email, pass, notelp, gender);
            SaveData sd = new SaveData();
            sd.userDaftarSimpan(data, "DataUser");
            
            Alert art = new Alert(Alert.AlertType.INFORMATION);
            art.setHeaderText(null);
            art.setTitle("PEMBERITAHUAN");
            art.setContentText("AKUN BERHASIL DIBUAT!");
            art.show();
            
            tfNama.setText("");
            tfEmail.setText("");
            tfPass.setText("");
            tfNoTelp.setText(""); 
            
            rbLaki.setSelected(false);
            rbPerempuan.setSelected(false);
            
        }     
    }
    
    @FXML
    private void txMasukNow(MouseEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanME(event, "/view/SceneMasuk.fxml");
    }

    @FXML
    private void keBeranda(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/StartupScene.fxml");
    }

    @FXML
    private void chGender(ActionEvent event) {
        if(rbLaki.isSelected()){
            lbGender.setText(rbLaki.getText());
        } else if (rbPerempuan.isSelected()){
            lbGender.setText(rbPerempuan.getText());
        }
    }
    
}
