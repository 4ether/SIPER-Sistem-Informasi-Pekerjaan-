package controller;

import model.SwitchPage;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import static javafx.collections.FXCollections.observableArrayList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import model.DataParse;
import model.DataUser;
import model.SaveData;

public class SceneProfilController implements Initializable {
    
  
    SceneMasukController smc = new SceneMasukController();
    ObservableList data = observableArrayList();
    SaveData sd = new SaveData();
    DataParse dp = new DataParse();
    DataUser du;
    
    

    
    @FXML
    private Label lbNama;
    @FXML
    private Label lbEmail;
    @FXML
    private Label lbNoTelp;
    @FXML
    private TableView tvUtama;
    @FXML
    private TableColumn tvNama;
    @FXML
    private TableColumn tvNoTelp;
    @FXML
    private TableColumn tvPass;
    @FXML
    private TableColumn tvEmail;
    @FXML
    private TableColumn tvGender;
    @FXML
    private TextField tfName;
    @FXML
    private TextField tfPass;
    @FXML
    private TextField tfNumber;
    @FXML
    private Button btnSave;
    @FXML
    private Label lbSandi;
    @FXML
    private Pane hiderPane;
    @FXML
    private Button btnTampil;
    @FXML
    private Button btnSembunyi;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {   
        
        data = sd.ambilDaftarSimpanUser("DataUser");
        tvNama.setCellValueFactory(new PropertyValueFactory<DataUser, String>("nama"));
        tvEmail.setCellValueFactory(new PropertyValueFactory<DataUser, String>("email"));
        tvPass.setCellValueFactory(new PropertyValueFactory<DataUser, String>("password"));
        tvNoTelp.setCellValueFactory(new PropertyValueFactory<DataUser, String>("notelp"));
        tvGender.setCellValueFactory(new PropertyValueFactory<DataUser, String>("gender"));
        tvUtama.setItems(data); 
  
        lbNama.setText(tvNama.getCellData(dp.getData()).toString());
        lbSandi.setText(tvPass.getCellData(dp.getData()).toString());
        lbEmail.setText(tvEmail.getCellData(dp.getData()).toString());
        lbNoTelp.setText(tvNoTelp.getCellData(dp.getData()).toString());   
        
    }
    
    
    @FXML
    private void back(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/MainScene.fxml");
    }
    
    
    
    
    @FXML
    private void chgName(ActionEvent event) {
        String email = tvEmail.getCellData(dp.getData()).toString();
        String passes = tvPass.getCellData(dp.getData()).toString();
        String notelps = tvNoTelp.getCellData(dp.getData()).toString();
        String genders = tvGender.getCellData(dp.getData()).toString();

        if (tfName.getText().isEmpty()) {
            Alert art = new Alert(Alert.AlertType.ERROR);
            art.setHeaderText(null);
            art.setContentText("Mohon masukan Nama baru!");
            art.show();
        } else {
            if(!tfName.getText().isEmpty()){
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("GANTI NAMA!!");
                alert.setContentText("Apakah anda yakin ingin mengganti nama anda ?");
                
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    data = sd.ambilDaftarSimpanUser("DataUser");   
                    data.set(dp.getData(), new DataUser(tfName.getText(), email, passes, notelps, genders));
                    tvUtama.setItems(data); 
                    btnSave.setVisible(true);
                    lbNama.setText(tfName.getText());
                } else {
                    
                }
            }
        } 
    }

    @FXML
    private void chgPass(ActionEvent event) {
        String names = tvNama.getCellData(dp.getData()).toString();
        String email = tvEmail.getCellData(dp.getData()).toString();
        String notelps = tvNoTelp.getCellData(dp.getData()).toString();
        String genders = tvGender.getCellData(dp.getData()).toString();

        if (tfPass.getText().isEmpty()) {
            Alert art = new Alert(Alert.AlertType.ERROR);
            art.setHeaderText(null);
            art.setContentText("Mohon masukan sandi baru!");
            art.show();
        } else {
            if(!tfPass.getText().isEmpty()){
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("GANTI SANDI!!");
                alert.setContentText("Apakah anda yakin ingin mengganti sandi anda ?");
                
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    data = sd.ambilDaftarSimpanUser("DataUser");   
                    data.set(dp.getData(), new DataUser(names, email, tfPass.getText(), notelps, genders));
                    tvUtama.setItems(data); 
                    btnSave.setVisible(true);
                    lbSandi.setText(tfPass.getText());
                } else {
                    
                }
            }
        } 
    }

    @FXML
    private void chgNumber(ActionEvent event) {
        String names = tvNama.getCellData(dp.getData()).toString();
        String email = tvEmail.getCellData(dp.getData()).toString();
        String passes = tvPass.getCellData(dp.getData()).toString();
        String notelps = tvNoTelp.getCellData(dp.getData()).toString();
        String genders = tvGender.getCellData(dp.getData()).toString();

        if (tfNumber.getText().isEmpty()) {
            Alert art = new Alert(Alert.AlertType.ERROR);
            art.setHeaderText(null);
            art.setContentText("Mohon masukan Nomor baru!");
            art.show();
        } else {
            if(!tfNumber.getText().isEmpty()){
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("GANTI NO TELEPON!!");
                alert.setContentText("Apakah anda yakin ingin mengganti No Telepon anda ?");
                
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    data = sd.ambilDaftarSimpanUser("DataUser");   
                    data.set(dp.getData(), new DataUser(names, email, passes, tfNumber.getText(), genders));
                    tvUtama.setItems(data); 
                    btnSave.setVisible(true);
                    lbNoTelp.setText(tfNumber.getText());
                } else {
                    
                }
            }
        } 
    }

    @FXML
    private void save(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("SIMPAN DATA");
        alert.setContentText("Apakah anda yakin ingin menyimpan perubahan ?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            sd.userDaftarSimpan(data, "DataUser");
            btnSave.setVisible(false);
        }
    }

    @FXML
    private void show(ActionEvent event) {
        hiderPane.setVisible(false);
        btnTampil.setVisible(false);
        btnSembunyi.setVisible(true);
    }

    @FXML
    private void hide(ActionEvent event) {
        hiderPane.setVisible(true);
        btnTampil.setVisible(true);
        btnSembunyi.setVisible(false);
    }

}
