package controller;

import model.SwitchPage;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.web.WebView;

public class SceneCSController implements Initializable {

    @FXML
    private Button btnBeranda;
    @FXML
    private WebView formCS;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        formCS.getEngine().load("https://forms.gle/MwS5CkG7G8LH4RMv6");
    }   

    @FXML
    private void keBeranda(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/MainScene.fxml");
    }

    @FXML
    private void openBrows(ActionEvent event) throws IOException {
        Desktop desktop = Desktop.getDesktop();
        desktop.browse(java.net.URI.create("https://forms.gle/MwS5CkG7G8LH4RMv6"));
    }
    
    
    
}
