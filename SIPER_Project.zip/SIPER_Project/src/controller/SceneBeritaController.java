package controller;

import model.SwitchPage;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;

public class SceneBeritaController implements Initializable {

    @FXML
    private Button btnBeranda;
    @FXML
    private AnchorPane apBerita;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    

    @FXML
    private void keBeranda(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/MainScene.fxml");
    }

    @FXML
    private void berita1(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/SceneBeritaSatu.fxml");
    }

    @FXML
    private void berita2(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/SceneBeritaDua.fxml");
    }

    @FXML
    private void berita3(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/SceneBeritaTiga.fxml");
    }
    
}
