package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import static javafx.collections.FXCollections.observableArrayList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import model.DataUser;
import model.SaveData;
import model.SwitchPage;

public class SceneGrafikUserController implements Initializable {

    ObservableList data = observableArrayList();
    SaveData sd = new SaveData();
    
    @FXML
    private TableView tvUtama;
    @FXML
    private TableColumn tvNama;
    @FXML
    private TableColumn tvEmail;
    @FXML
    private TableColumn tvPass;
    @FXML
    private TableColumn tvNoTelp;
    @FXML
    private TableColumn tvGender;
    @FXML
    private PieChart pcGender;
    @FXML
    private BarChart<String, Integer> bcGender;
    @FXML
    private Button btnBeranda;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // Database
        data = sd.ambilDaftarSimpanUser("DataUser");
        tvNama.setCellValueFactory(new PropertyValueFactory<DataUser, String>("nama"));
        tvEmail.setCellValueFactory(new PropertyValueFactory<DataUser, String>("email"));
        tvPass.setCellValueFactory(new PropertyValueFactory<DataUser, String>("password"));
        tvNoTelp.setCellValueFactory(new PropertyValueFactory<DataUser, String>("notelp"));
        tvGender.setCellValueFactory(new PropertyValueFactory<DataUser, String>("gender"));
        tvUtama.setItems(data); 
        
        // Pie Chart    
        ArrayList<String> gdListL = new ArrayList<String>();
        ArrayList<String> gdListP = new ArrayList<String>();
           
        for (int i = 0; i < tvUtama.getItems().size(); i++) {
            if (tvGender.getCellData(i).toString().equals("Laki-Laki")) {
                gdListL.add(tvGender.getCellData(i).toString());
            } else if (tvGender.getCellData(i).toString().equals("Perempuan")) {
                gdListP.add(tvGender.getCellData(i).toString());
            }   
        }
        
        ObservableList<PieChart.Data> pcGenderData = FXCollections.observableArrayList(
                    new PieChart.Data("Laki-Laki", gdListL.size()),
                    new PieChart.Data("Perempuan", gdListP.size())
                            );
        pcGenderData.forEach(data ->
                data.nameProperty().bind(
                        Bindings.concat(
                                        data.getName(), "Jumlah: ", data.pieValueProperty()
                        )
                )
        );  
        pcGender.getData().addAll(pcGenderData);
        
        // Bar Chart
        XYChart.Series<String, Integer> bcGenderS = new XYChart.Series();
        
        bcGenderS.getData().add(new XYChart.Data<>("Laki-Laki", gdListL.size()));
        bcGenderS.getData().add(new XYChart.Data<>("Perempuan", gdListP.size()));
        bcGender.getData().addAll(bcGenderS);
    }    

    @FXML
    private void keBeranda(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/MainScene.fxml");
    }
    
}
