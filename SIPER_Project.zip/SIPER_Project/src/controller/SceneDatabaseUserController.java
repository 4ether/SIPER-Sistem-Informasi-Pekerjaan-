package controller;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import static javafx.collections.FXCollections.observableArrayList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.DataUser;
import model.SaveData;
import model.SwitchPage;


public class SceneDatabaseUserController implements Initializable {
    
    ObservableList data = observableArrayList();  

    @FXML
    private Button btnSave;
    @FXML
    private Button btnReset;
    @FXML
    private Button btnBeranda;
    @FXML
    private TableColumn tvGender;
    
    public void addDatabase(String nama, String email, String password, String notelp, String gender){
        data.add(new DataUser(nama, email, password, notelp, gender));
    }
    
    @FXML
    private TableView tvUtama;
    @FXML
    private TableColumn tvNama;
    @FXML
    private TableColumn tvEmail;
    @FXML
    private TableColumn tvPassword;
    @FXML
    private TableColumn tvNoTelepon;
    
    
    // Tester
    public String getEmail(){
        return tvEmail.toString();
    }
    
    public String getPassword(){
        return tvPassword.toString();
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            SaveData sd = new SaveData();
            data = sd.ambilDaftarSimpanUser("DataUser");
            tvNama.setCellValueFactory(new PropertyValueFactory<DataUser, String>("nama"));
            tvEmail.setCellValueFactory(new PropertyValueFactory<DataUser, String>("email"));
            tvPassword.setCellValueFactory(new PropertyValueFactory<DataUser, String>("password"));
            tvNoTelepon.setCellValueFactory(new PropertyValueFactory<DataUser, String>("notelp"));
            tvGender.setCellValueFactory(new PropertyValueFactory<DataUser, String>("gender"));
            tvUtama.setItems(data);
        } catch(Exception e){
            System.out.println("Database akun belum ada!");
        }
    }    

    @FXML
    private void keBeranda(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/MainSceneAdminLogined.fxml");
    }

    @FXML
    private void delAccount(ActionEvent event) {
        for (int i = 0; i < tvUtama.getItems().size(); i++) {
            if (tvUtama.getSelectionModel().isSelected(i)) {
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("HAPUS AKUN TERPILIH !!");
                alert.setContentText("Apakah anda yakin ingin menghapus akun ?");

                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    int selectedID = tvUtama.getSelectionModel().getSelectedIndex();
                    tvUtama.getItems().remove(selectedID);
                    btnSave.setVisible(true);
                    btnReset.setVisible(true);
                } else {
                    
                }
            }
        }
    }

    @FXML
    private void saveDat(ActionEvent event) {

        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("SIMPAN DATA");
        alert.setContentText("Apakah anda yakin ingin menyimpan perubahan ?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            SaveData sd = new SaveData();
            sd.userDaftarSimpan(data, "DataUser");
            btnSave.setVisible(false);
            btnReset.setVisible(false);
        }
    }

    @FXML
    private void resetDat(ActionEvent event) {
        SaveData sd = new SaveData();
        data = sd.ambilDaftarSimpanUser("DataUser");
        tvNama.setCellValueFactory(new PropertyValueFactory<DataUser, String>("nama"));
        tvEmail.setCellValueFactory(new PropertyValueFactory<DataUser, String>("email"));
        tvPassword.setCellValueFactory(new PropertyValueFactory<DataUser, String>("password"));
        tvNoTelepon.setCellValueFactory(new PropertyValueFactory<DataUser, String>("notelp"));
        tvUtama.setItems(data);
        btnSave.setVisible(false);
        btnReset.setVisible(false);
    }

}
