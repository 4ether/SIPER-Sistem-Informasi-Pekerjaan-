package controller;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.SwitchPage;


public class ScenePekerjaanDuaController implements Initializable {

    @FXML
    private Button btnDaftar;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    

    @FXML
    private void contactWA(ActionEvent event) throws IOException {
        Desktop desktop = Desktop.getDesktop();
        desktop.browse(java.net.URI.create("https://wa.me/088246259851"));
    }
    
    @FXML
    private void contactWA2(ActionEvent event) throws IOException {
        Desktop desktop = Desktop.getDesktop();
        desktop.browse(java.net.URI.create("https://wa.me/081258085800"));
    }
    
    @FXML
    private void visitIG(ActionEvent event) throws IOException {
        Desktop desktop = Desktop.getDesktop();
        desktop.browse(java.net.URI.create("https://www.instagram.com/bintang_banua_angkasa/"));
    }

    @FXML
    private void back(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/SceneCariKerja.fxml");
    }

    @FXML
    private void daftarNow(ActionEvent event) throws IOException {
        btnDaftar.setDisable(true);
        Parent root = FXMLLoader.load(getClass().getResource("/view/SceneUploadCV.fxml"));       
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.initModality(Modality.WINDOW_MODAL);
        primaryStage.showAndWait();
        
        if(primaryStage.isShowing() == false){
            btnDaftar.setDisable(false);           
        }
    }

    
    
}
