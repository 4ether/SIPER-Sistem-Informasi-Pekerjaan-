package controller;

import java.io.File;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;

public class SceneUploadCVController implements Initializable {

    FileChooser fc = new FileChooser();
    @FXML
    private TextField tfLocate;
    @FXML
    private Button sendBtn;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    

    @FXML
    private void upload(ActionEvent event) {
        
        fc.getExtensionFilters().addAll(new ExtensionFilter("PDF Files", "*.pdf", "*.PDF"));
        File selectedFile = fc.showOpenDialog(null);
        
        if (selectedFile != null) {
            tfLocate.setText(selectedFile.getAbsolutePath());            
        } else {
            
        }   
        
        if (!tfLocate.getText().isEmpty()){
            sendBtn.setVisible(true);
        }
    }

    @FXML
    private void send(ActionEvent event) {    
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("KIRIM CV!!");
        alert.setContentText("Apakah anda yakin ingin mengirim CV?");
        
        
        
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) { 
            Alert art = new Alert(Alert.AlertType.INFORMATION);
            art.setHeaderText(null);
            art.setTitle("TERKIRIM!");
            art.setContentText("CV berhasil terkirim, silahkan menunggu kabar selanjutnya");
            art.show();
            tfLocate.setText("");
            sendBtn.setVisible(false);
            
        } else {

        }
       
    }

}
