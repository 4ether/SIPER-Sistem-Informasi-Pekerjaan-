package controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import model.SwitchPage;


public class MainSceneAdminLoginedController implements Initializable {

    
    @FXML
    private ImageView padBeritaPekerjaan;
    @FXML
    private ImageView padCustomerService;
    @FXML
    private Button btnLogout;
    @FXML
    private ImageView padDataAkunUser;
    @FXML
    private ImageView padGrafikUsia;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
    

    @FXML
    private void logoutAdmin(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/StartupScene.fxml");
    }

    @FXML
    private void padDatabaseAkun(MouseEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanME(event, "/view/SceneDatabaseUser.fxml");
    }

    @FXML
    private void padUpdateBerita(MouseEvent event) {
        
    }

    @FXML
    private void padCustomerAdvice(MouseEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanME(event, "/view/ScenePendapat.fxml");  
    }

    @FXML
    private void padGrafikUsia(MouseEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanME(event, "/view/SceneGrafikAdmin.fxml");  
    }



}
