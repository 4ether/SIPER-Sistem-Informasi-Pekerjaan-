package controller;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.web.WebView;
import model.SwitchPage;


public class ScenePendapatController implements Initializable {

    @FXML
    private WebView wvSaran;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        wvSaran.getEngine().load("https://docs.google.com/forms/d/1mIabvKHzzqapnF0srtZXuqLdhCMg7mRRDSu6rDv2p50/edit#responses");
    }    

    @FXML
    private void keBeranda(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/MainSceneAdminLogined.fxml");
    }

    @FXML
    private void keBrowser(ActionEvent event) throws IOException {
        Desktop desktop = Desktop.getDesktop();
        desktop.browse(java.net.URI.create("https://docs.google.com/forms/d/1mIabvKHzzqapnF0srtZXuqLdhCMg7mRRDSu6rDv2p50/edit#responses"));
    }
    
}
