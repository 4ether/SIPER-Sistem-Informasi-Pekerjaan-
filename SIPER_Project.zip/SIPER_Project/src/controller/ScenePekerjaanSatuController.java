package controller;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.SwitchPage;


public class ScenePekerjaanSatuController implements Initializable {

    @FXML
    private Button btnDaftar;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    

    @FXML
    private void visitWeb(ActionEvent event) throws IOException {
        Desktop desktop = Desktop.getDesktop();
        desktop.browse(java.net.URI.create("https://recruitment.kai.id"));
    }

    @FXML
    private void visitTwitter(ActionEvent event) throws IOException {
        Desktop desktop = Desktop.getDesktop();
        desktop.browse(java.net.URI.create("https://twitter.com/KAI121"));
    }

    @FXML
    private void back(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/SceneCariKerja.fxml");
    }

    @FXML
    private void daftarNow(ActionEvent event) throws IOException  {
        btnDaftar.setDisable(true);
        Parent root = FXMLLoader.load(getClass().getResource("/view/SceneUploadCV.fxml"));       
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.initModality(Modality.WINDOW_MODAL);
        primaryStage.showAndWait();
        
        if(primaryStage.isShowing() == false){
            btnDaftar.setDisable(false);           
        }
    }
    
}
