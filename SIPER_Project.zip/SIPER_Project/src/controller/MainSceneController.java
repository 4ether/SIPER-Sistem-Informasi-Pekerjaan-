package controller;

import model.SwitchPage;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.TranslateTransition;
import static javafx.collections.FXCollections.observableArrayList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import model.DataParse;
import model.DataUser;
import model.SaveData;

public class MainSceneController implements Initializable {
    
    ObservableList data = observableArrayList();
    
    @FXML
    private Label Menu;
    @FXML
    private AnchorPane slider;
    @FXML
    private Label MenuClose;
    @FXML
    private Button btnProfil;
    @FXML
    private Button btnPengaturan;
    @FXML
    private Button btnTentang;
    @FXML
    private Button btnCustomerService;
    @FXML
    private ImageView padCariPekerjaan;
    @FXML
    private ImageView padBeritaPekerjaan;
    @FXML
    private TableView tvUtama;
    @FXML
    private TableColumn tvNama;
    @FXML
    private TableColumn tvEmail;
    @FXML
    private TableColumn tvPass;
    @FXML
    private TableColumn tvNoTelp;
    @FXML
    private Label lbNama;
    @FXML
    private TableColumn tvGender;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // Selamat Datang <Nama> ============================
        SaveData sd = new SaveData();
        DataParse dp = new DataParse();
        data = sd.ambilDaftarSimpanUser("DataUser");
        tvNama.setCellValueFactory(new PropertyValueFactory<DataUser, String>("nama"));
        tvEmail.setCellValueFactory(new PropertyValueFactory<DataUser, String>("email"));
        tvPass.setCellValueFactory(new PropertyValueFactory<DataUser, String>("password"));
        tvNoTelp.setCellValueFactory(new PropertyValueFactory<DataUser, String>("notelp"));
        tvGender.setCellValueFactory(new PropertyValueFactory<DataUser, String>("gender"));
        tvUtama.setItems(data); 
        
        lbNama.setText(tvNama.getCellData(dp.getData()).toString());
        
        // Slider ===========================================
        slider.setTranslateX(0);
        
        Menu.setOnMouseClicked(event -> {
            TranslateTransition slide = new TranslateTransition();
            slide.setDuration(Duration.seconds(0.4));
            slide.setNode(slider);
            
            slide.setToX(0);
            slide.play();
            
            slider.setTranslateX(-540);
            
            slide.setOnFinished((ActionEvent e) -> {
                Menu.setVisible(false);
                MenuClose.setVisible(true);
            });
        });
        
        MenuClose.setOnMouseClicked(event -> {
            TranslateTransition slide = new TranslateTransition();
            slide.setDuration(Duration.seconds(0.4));
            slide.setNode(slider);
            
            slide.setToX(-540);
            slide.play();
            
            slider.setTranslateX(0);
            
            slide.setOnFinished((ActionEvent e) -> {
                Menu.setVisible(true);
                MenuClose.setVisible(false);
            });
        });
        
    }    
       
    
    @FXML
    private void padCariKerja(MouseEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanME(event, "/view/SceneCariKerja.fxml");
    }
    
    @FXML
    private void padInfoKerja(MouseEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanME(event, "/view/SceneBerita.fxml");
    }
    
    

    @FXML
    private void profil(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/SceneProfil.fxml");
    }


    @FXML
    private void tentang(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/SceneAbout.fxml");
    }

    @FXML
    private void customerservice(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/SceneCS.fxml");
    }

    @FXML
    private void logoutUser (ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/StartupScene.fxml");
    }

    @FXML
    private void grafik(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/SceneGrafikUser.fxml");
    }
      
    
}
