package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import static javafx.collections.FXCollections.observableArrayList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import model.SwitchPage;
import model.AdminData;
import model.DataParse;
import model.DataUser;
import model.SaveData;

public class SceneMasukController implements Initializable {

    SaveData sd = new SaveData();
    AdminData ad = new AdminData();
    ObservableList data = observableArrayList();

    SceneDatabaseUserController sduc;

    String email = ad.getEmail();
    String password = ad.getPassword();
    private int counter;

    @FXML
    private TextField tfEmail;
    @FXML
    private PasswordField tfPassword;
    @FXML
    private TableView tvUtama;
    @FXML
    private TableColumn tvNama;
    @FXML
    private TableColumn tvEmail;
    @FXML
    private TableColumn tvPass;
    @FXML
    private TableColumn tvNoTelp;
    @FXML
    private Button btnMasuk;
    @FXML
    private Text txDaftar;
    @FXML
    private Button btnBeranda;
    @FXML
    private TableColumn tvGender;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            SaveData sd = new SaveData();
            data = sd.ambilDaftarSimpanUser("DataUser");
            tvNama.setCellValueFactory(new PropertyValueFactory<DataUser, String>("nama"));
            tvEmail.setCellValueFactory(new PropertyValueFactory<DataUser, String>("email"));
            tvPass.setCellValueFactory(new PropertyValueFactory<DataUser, String>("password"));
            tvNoTelp.setCellValueFactory(new PropertyValueFactory<DataUser, String>("notelp"));
            tvGender.setCellValueFactory(new PropertyValueFactory<DataUser, String>("gender"));
            tvUtama.setItems(data);
        } catch(Exception e){
            System.out.println("Database akun belum ada!");
        }

    }

    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/view/MainScene.fxml"));

        Scene scene = new Scene(root);

        stage.setTitle("MASUK AKUN");
        stage.setScene(scene);
        stage.show();
    }

    public String getText(){
        return tfEmail.getText();
    }
    
    public String getPass(){
        return tfPassword.getText();
    }
    
    @FXML
    private void btnUserMasuk(ActionEvent event) throws InterruptedException  {
        String emails = tfEmail.getText();
        String pass = tfPassword.getText();
        DataParse dp = new DataParse();
        
        boolean cond1 = false, cond2 = false;

        ArrayList<String> emList = new ArrayList<String>();
        ArrayList<String> psList = new ArrayList<String>();

        for (int i = 0; i < tvUtama.getItems().size(); i++) {
            emList.add(tvEmail.getCellData(i).toString());
            psList.add(tvPass.getCellData(i).toString());
        }
                
        for (counter = 0; counter < tvUtama.getItems().size(); counter++) {
            DataParse.dataparse = counter;
            if (emList.get(counter).equals(emails) && psList.get(counter).equals(pass)) {
                SwitchPage sp = new SwitchPage();
                sp.pindahHalamanAE(event, "/view/MainScene.fxml");
                break;

            } else if (emails.isEmpty() || pass.isEmpty()) {
                Alert art = new Alert(Alert.AlertType.ERROR);
                art.setHeaderText(null);
                art.setContentText("Mohon masukan semua data!");
                art.show();
                break;

            } else if (emails.equals(email) && pass.equals(password)) {
                SwitchPage sp = new SwitchPage();
                sp.pindahHalamanAE(event, "/view/MainSceneAdminLogined.fxml");
                break;
            } else if (!emList.contains(emails) && !psList.contains(pass)) {
                Alert art = new Alert(Alert.AlertType.ERROR);
                art.setHeaderText(null);
                art.setContentText("Akun belum terdaftar!");
                art.show();
                break;
            } 
            
            // Checking condition
            if (emList.get(dp.getData()).equals(emails) && !psList.get(dp.getData()).equals(pass)){
                cond1 = true;
            } else {
                cond2 = true;
            }
            
            // Condition
            if(cond1 == true && cond2 == true){
                Alert art = new Alert(Alert.AlertType.ERROR);
                art.setHeaderText(null);
                art.setContentText("Email atau password salah!");
                art.show();
                break;
            }
        } 
    } 
    
    

    @FXML
    private void txDaftarNow(MouseEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanME(event, "/view/SceneDaftar.fxml");
    }

    @FXML
    private void keBeranda(ActionEvent event) throws InterruptedException {
        SwitchPage sp = new SwitchPage();
        sp.pindahHalamanAE(event, "/view/StartupScene.fxml");
    }

}
