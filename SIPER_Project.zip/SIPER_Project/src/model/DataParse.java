package model;

public class DataParse {
    
    public static int dataparse = 0;
    
    public int getData(){
        return dataparse;
    }
}
