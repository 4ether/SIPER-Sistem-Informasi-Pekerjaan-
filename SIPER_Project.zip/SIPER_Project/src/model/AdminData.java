package model;

public class AdminData {
    
    private final String email = "admin@admin.com";
    private final String password = "adminsiper";
    
    public String getEmail(){
        return email;
    }
    
    public String getPassword(){
        return password;
    }
}
